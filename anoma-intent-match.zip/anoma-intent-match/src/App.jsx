import React, { useMemo, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

// ---------------------- Content (from your spec) ----------------------
const OVERVIEW = {
  headline: "Welcome to Anoma: Web3’s Intent-Centric Operating System",
  sub: "Build and use decentralized apps that prioritize user outcomes, not complex transactions.",
  text: `Anoma is a distributed operating system designed to simplify Web3. Unlike traditional blockchains, Anoma’s intent-centric approach lets users express desired outcomes—like trading assets or sharing data—while its decentralized solver network handles the rest. Developers can build apps that work across any blockchain, offering seamless scalability and user control over data. Whether you’re a developer or a user, Anoma makes decentralized apps intuitive, unified, and powerful.`,
  features: [
    { title: "Intent-Centric", body: "Focus on what users want, not how to get it." },
    { title: "Cross-Chain", body: "Deploy once, connect to any blockchain." },
    { title: "Scalable", body: "Distributed architecture for limitless growth." },
    { title: "Private & Sovereign", body: "Users control their data with zero-knowledge proofs." },
  ],
  ctas: [
    { label: "Start Building", href: "https://docs.anoma.net" },
    { label: "Join Community", href: "https://anoma.net" }, // Discord via anoma.net
    { label: "Learn More", href: "https://anoma.net" },
  ]
}

// ---------------------- Intent Match Game ----------------------
// Minimal HTML5 drag & drop. You act like a solver matching Buy/Sell intents.
const ASSETS = ["ETH", "BTC", "USDC", "DAI"]
const AMOUNTS = [1, 5, 10, 25, 100]

function makeIntent(id, side, asset, amount) {
  return { id, side, asset, amount }
}

function generateRound(nPairs=6) {
  const intents = []
  let id = 1
  for (let i=0; i<nPairs; i++) {
    const asset = ASSETS[Math.floor(Math.random()*ASSETS.length)]
    const amount = AMOUNTS[Math.floor(Math.random()*AMOUNTS.length)]
    // complementary pair: Buy X / Sell X
    intents.push(makeIntent(id++, "Buy", asset, amount))
    intents.push(makeIntent(id++, "Sell", asset, amount))
  }
  // shuffle
  for (let i=intents.length-1; i>0; i--) {
    const j = Math.floor(Math.random()*(i+1))
    ;[intents[i], intents[j]] = [intents[j], intents[i]]
  }
  return intents
}

function intentLabel(i) {
  return `${i.side} ${i.amount} ${i.asset}`
}

export default function App() {
  const [intents, setIntents] = useState(() => generateRound(6))
  const [dragging, setDragging] = useState(null)
  const [score, setScore] = useState(0)
  const [message, setMessage] = useState("Drag and drop to match complementary intents.")
  const [shakes, setShakes] = useState({}) // id -> boolean to trigger shake

  const remaining = intents.length

  function reset() {
    setIntents(generateRound(6))
    setScore(0)
    setMessage("New round! Match the intents to score points.")
    setShakes({})
  }

  function onDragStart(e, intent) {
    e.dataTransfer.setData("text/plain", String(intent.id))
    setDragging(intent.id)
  }

  function onDragEnd() {
    setDragging(null)
  }

  function onDrop(e, target) {
    e.preventDefault()
    const idStr = e.dataTransfer.getData("text/plain")
    const src = intents.find(i => String(i.id) === idStr)
    if (!src || src.id === target.id) return

    const isMatch = src.asset === target.asset && src.amount === target.amount && src.side !== target.side
    if (isMatch) {
      // remove both
      const next = intents.filter(i => i.id !== src.id && i.id !== target.id)
      setIntents(next)
      setScore(s => s + 2)
      setMessage(`Matched: ${intentLabel(src)} ⇄ ${intentLabel(target)}!`)
    } else {
      // penalty + shake both cards briefly
      setScore(s => Math.max(0, s - 1))
      setMessage("Mismatch. Try again!")
      setShakes(prev => ({ ...prev, [src.id]: true, [target.id]: true }))
      setTimeout(() => setShakes(prev => ({ ...prev, [src.id]: false, [target.id]: false })), 350)
    }
    setDragging(null)
  }

  function allowDrop(e) { e.preventDefault() }

  const won = remaining === 0

  return (
    <div>
      {/* Hero / Overview */}
      <section className="section py-16 md:py-24">
        <div className="flex flex-col items-center text-center">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-5xl font-extrabold tracking-tight"
          >
            {OVERVIEW.headline}
          </motion.h1>
          <p className="mt-4 text-lg md:text-xl text-white/80 max-w-3xl">{OVERVIEW.sub}</p>

          {/* Minimalist hero graphic */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="relative mt-10 h-40 w-full max-w-3xl card overflow-hidden"
            aria-hidden="true"
          >
            <svg viewBox="0 0 600 200" className="absolute inset-0 w-full h-full">
              <defs>
                <radialGradient id="g" fx="50%" fy="50%">
                  <stop offset="0%" stopColor="#39FF14" stopOpacity="0.9" />
                  <stop offset="100%" stopColor="#39FF14" stopOpacity="0" />
                </radialGradient>
              </defs>
              {[...Array(14)].map((_, i) => (
                <circle key={i} cx={40 + i*40} cy={100 + (i%2? -20:20)} r="4" fill="#39FF14" />
              ))}
              {[...Array(13)].map((_, i) => (
                <line key={i} x1={44 + i*40} y1={100 + (i%2? -20:20)} x2={80 + i*40} y2={100 + (i%2? 20:-20)} stroke="url(#g)" strokeWidth="2"/>
              ))}
            </svg>
          </motion.div>

          <p className="mt-8 max-w-4xl text-white/80">{OVERVIEW.text}</p>

          {/* Features */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-10 w-full">
            {OVERVIEW.features.map((f, idx) => (
              <div key={idx} className="card p-5 text-left">
                <div className="badge mb-2">{f.title}</div>
                <p className="text-white/85">{f.body}</p>
              </div>
            ))}
          </div>

          {/* CTAs */}
          <div className="flex flex-wrap items-center justify-center gap-3 mt-8">
            {OVERVIEW.ctas.map((c, idx) => (
              <a key={idx} href={c.href} target="_blank" rel="noreferrer" className={idx === 0 ? "btn btn-primary" : "btn"}>
                {c.label}
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* Divider */}
      <div className="section">
        <div className="h-px w-full bg-gradient-to-r from-transparent via-white/20 to-transparent my-6" />
      </div>

      {/* Intent Match Game */}
      <section id="intent-match" className="section py-12 md:py-16">
        <div className="max-w-5xl mx-auto">
          <div className="text-center">
            <h2 className="text-2xl md:text-4xl font-bold">Try Intent Match: Be a Solver in Anoma’s Network!</h2>
            <p className="mt-2 text-white/80">Drag and drop to match user intents and see how Anoma powers seamless, cross-chain trades.</p>
          </div>

          <div className="mt-6 card p-6">
            <div className="md:flex md:items-start md:gap-6">
              {/* Instructions */}
              <ul className="md:w-72 space-y-2 list-disc list-inside text-sm text-white/80 mb-6 md:mb-0">
                <li>Drag intents onto complementary ones (e.g., “Sell 1 ETH” with “Buy 1 ETH”).</li>
                <li>Earn points for each successful match.</li>
                <li>Watch out for mismatches — they’ll cost you points!</li>
              </ul>

              {/* Game Area */}
              <div className="flex-1">
                <div className="flex items-center justify-between mb-4">
                  <div className="text-sm text-white/70">Score: <span className="font-semibold text-white">{score}</span></div>
                  <div className="text-sm text-white/70">Remaining: <span className="font-semibold text-white">{remaining}</span></div>
                  <button className="btn" onClick={reset}>Reset</button>
                </div>

                {won && (
                  <div className="mb-4 rounded-xl p-4 bg-emerald-400/10 border border-emerald-500/30">
                    <div className="font-semibold text-emerald-300">All intents matched! 🎉</div>
                    <div className="text-sm text-emerald-200/90">Try Reset to play again.</div>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {intents.map((i) => (
                    <motion.div
                      key={i.id}
                      className={`p-4 card select-none ${dragging===i.id ? "ring-2 ring-[var(--accent)]" : ""} ${shakes[i.id] ? "animate-[shake_0.35s_linear]" : ""}`}
                      draggable
                      onDragStart={(e) => onDragStart(e, i)}
                      onDragEnd={onDragEnd}
                      onDragOver={allowDrop}
                      onDrop={(e) => onDrop(e, i)}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      style={{ cursor: "grab" }}
                    >
                      <div className="flex items-center justify-between">
                        <span className="badge">{i.side}</span>
                        <span className="text-xs text-white/60">{i.asset}</span>
                      </div>
                      <div className="mt-2 text-lg font-semibold">{i.amount} {i.asset}</div>
                      <div className="mt-1 text-xs text-white/60">Drag onto its complement</div>
                    </motion.div>
                  ))}
                </div>

                <div className="mt-4 text-sm text-white/80">{message}</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <footer className="section py-10 text-center text-white/50 text-xs">
        <div>© {new Date().getFullYear()} Anoma — Intent-Centric OS. Demo site & game for educational purposes.</div>
      </footer>

      <style>{`
        @keyframes shake {
          10%, 90% { transform: translateX(-1px); }
          20%, 80% { transform: translateX(2px); }
          30%, 50%, 70% { transform: translateX(-4px); }
          40%, 60% { transform: translateX(4px); }
        }
      `}</style>
    </div>
  )
}
